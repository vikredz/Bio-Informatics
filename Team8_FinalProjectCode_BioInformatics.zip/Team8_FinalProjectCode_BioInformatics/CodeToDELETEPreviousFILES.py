import os

#This function is to delete the files from the ouput folder to generate new files
def deletePreviousFiles(folder_path):
    file_list = os.listdir(folder_path)

    if(len(file_list)>0):
        # Iterate through the files and delete each one
        for file_name in file_list:
            file_path = os.path.join(folder_path, file_name)
            try:
                if os.path.isfile(file_path):
                    os.remove(file_path)
                    print(f"Deleted: {file_path}")
                else:
                    print(f"{file_path} is not a file.")
            except Exception as e:
                print(f"Error deleting {file_path}: {e}")



# call the method to delete the previously generated files
folder_path = os.path.abspath("output/nj")
deletePreviousFiles(folder_path)
folder_path2 = os.path.abspath("output/upgma")
deletePreviousFiles(folder_path2)