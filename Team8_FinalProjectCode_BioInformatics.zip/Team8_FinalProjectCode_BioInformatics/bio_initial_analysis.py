# Install and Import all the dependencies
import pandas as pd
import matplotlib.pyplot as plt

#initialize the base sequence
dnaBase = "ACGTN"

# function to create the sequence count 
def sequenceCount(seq1, seq2):

    #initialize the default values
    match_count = 0
    mismatch_count = 0
    gap_count = 0
    is_gap = False
    current_gap_len = 0
    gap_count_len = [0] * 5000
    max_gap_len = 0

    #getting the minimum sequence length from two sequence
    seq = min(len(seq1), len(seq2))

    for i in range(seq):
        c1 = seq1[i].upper()
        c2 = seq2[i].upper()

        #calculating the gapCount
        if c1 not in dnaBase or c2 not in dnaBase:
            if c1 == '-' or c2 == '-':
                if is_gap:
                    current_gap_len += 1
                else:
                    is_gap = True
                    current_gap_len = 1
                    gap_count += 1
            continue

        if is_gap:
            gap_count_len[current_gap_len] += 1
            if current_gap_len > max_gap_len:
                max_gap_len = current_gap_len
            is_gap = False

        #calculating the match and mismatch count
        if c1 == c2:
            match_count += 1
        else:
            mismatch_count += 1

    if is_gap:
        gap_count_len[current_gap_len] += 1
        if current_gap_len > max_gap_len:
            max_gap_len = current_gap_len
    
    return match_count, mismatch_count, gap_count

# function to read the input file and process 
def processInputMAFFile(filename):

    #Reading the input file
    with open(filename, 'r') as inputStream:
        if not inputStream:
            print(f"Error: Unable to open file \"{filename}\" for reading!")
            return
        print(f"File is opened: {filename}")
        
        geneBaseTypeCount = 0
        geneBaseTypes = [None, None]
        sequenceStartInd = 's'
        inputLine = ""

        match_dict = {}
        misMatch_dict = {}
        gapCount_dict = {}

        #extracting the sequences and passing as a parameters to the sequenceCount function        
        for line in inputStream:
            inputLine = line.strip()
            if inputLine.startswith(sequenceStartInd):
                if geneBaseTypeCount == 0:
                    # Save the first 's' line for comparison
                    geneBaseTypes[0] = inputLine.split()[6]
                    geneBaseTypeCount +=1
                else:
                    # Compare the first 's' line to the current 's' line
                    geneBaseTypes[1] = inputLine.split()[6]
                    geneBaseTypeCount +=1
                if geneBaseTypeCount == 2:

                    match_count, mismatch_count, gap_count = sequenceCount(geneBaseTypes[0], geneBaseTypes[1])

                    if (inputLine.split()[1]) in match_dict:

                        match_dict[inputLine.split()[1]] =  match_dict[inputLine.split()[1]] + match_count 
                        misMatch_dict[inputLine.split()[1]] =  misMatch_dict[inputLine.split()[1]] + mismatch_count
                        gapCount_dict[inputLine.split()[1]] =  gapCount_dict[inputLine.split()[1]] + gap_count

                    else:
                        match_dict[inputLine.split()[1]] =   match_count 
                        misMatch_dict[inputLine.split()[1]] =  mismatch_count
                        gapCount_dict[inputLine.split()[1]] =  gap_count


                    geneBaseTypeCount =1
                       
            elif inputLine.startswith('a'):
                geneBaseTypes = [None, None]
                geneBaseTypeCount = 0
        
        return match_dict, misMatch_dict, gapCount_dict
    
# function to visulaize the data
def visualize(xAxis, yAxis, xName, yName, title):
    plt.figure(figsize=(10, 6))
    plt.bar(xAxis, yAxis, color='blue')
    plt.xlabel(xName)
    plt.ylabel(yName)
    plt.title(title)
    plt.xticks(rotation=90)  # Rotate the x-axis labels by 90 degrees
    plt.show()


#call the  processInputMAFFile to get the match, mismatch and gapCount dictionary              
match_dict, misMatch_dict, gapCount_dict = processInputMAFFile("input/multi.sars-like.maf")

substitutionRate_dict ={}
gapRateDict = {}

#calculating the gap rate and substitution rate from the matchCount, mismatchCount and gapCount
for key in match_dict:
    substitutionRate_dict[key] = misMatch_dict[key]/(match_dict[key] + misMatch_dict[key])
    gapRateDict[key] = gapCount_dict[key]/(gapCount_dict[key] + match_dict[key] + misMatch_dict[key])

#Creating the data frame with gap rate and substitution rate data
data = {'key': list(match_dict.keys()),
        'match_count': list(match_dict.values()),
        'mismatch_count': list(misMatch_dict.values()),
        'gap_count': list(gapCount_dict.values()),
        'gap_rate': list(gapRateDict.values()),
        'substitution_rate': list(substitutionRate_dict.values())
        }

df = pd.DataFrame(data)
print(df)

visualize(df["key"],df['gap_rate'], "Genome","Gap Rate", "Gap rate for multi.sars-like with MN988668 geneome")

visualize(df["key"],df['substitution_rate'], "Genome","Substitution Rate", "Substitution rate for multi.sars-like with MN988668 geneome")


