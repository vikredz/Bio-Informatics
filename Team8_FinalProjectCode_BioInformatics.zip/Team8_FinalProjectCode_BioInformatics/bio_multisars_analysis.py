# Install and Import all the dependencies
from Bio.Phylo.TreeConstruction import DistanceCalculator,DistanceTreeConstructor
from Bio.Align import MultipleSeqAlignment
from Bio import AlignIO, Phylo, SeqRecord
from Bio.Seq import Seq
import matplotlib.pyplot as plt
import dendropy
from dendropy.calculate import treecompare
import pandas as pd
import numpy as np
import seaborn as sns

#initiliaze the genome list object
genomeList = []


# Setup DendroPy configuration
tns_namespace = dendropy.TaxonNamespace()

# Function to get the major sars cov 2 genes and their start and end postions
def get_gene_positions():
    gene_positions = [["Whole", "0", "0"]]

    #read all genes from sarsCov2structure.txt
    with open("input/sarsCov2structure.txt") as file:
        for line in file.readlines():
            position_list = line.split(None)
            if(position_list):
                gene_positions.append(position_list)
    return gene_positions


# Function to get the full genome list from the input file
def get_genome_list(align):
    genome_list = []
    for alignBlock in align:
        for seqRecord in alignBlock:
            genome_id = seqRecord.id
            if genome_id not in genome_list:
                genome_list.append(genome_id)
    main_gen = genome_list[0]
    genome_list.pop(0) 
    genome_list.insert(26,main_gen)           
    return genome_list

#Function to extract the specfic genes from the genome sequence
def extract_gene_by_position(align, start, end):

    #create an empty multiple sequence alignment object
    obj_MSA = MultipleSeqAlignment([])

    #build sequences from the cleaned strings to form new Multiple Alignment Sequence
    for key in genomeList:
        gene_sequence = ""
        
        for align_block in align:
            for seq_record in align_block:
                if seq_record.id == key:
                    gene_sequence += seq_record.seq

        # For the whole genome, select the entire sequence            
        if end == 0:
            end = len(gene_sequence) - 1  
            
        sub_seq = ""
        
        if len(gene_sequence) > end:
            sub_seq = gene_sequence[start:end]
            
            processed_seq = SeqRecord.SeqRecord(sub_seq, id=key)
            obj_MSA.append(processed_seq)
    
    return obj_MSA

#Compute conservated regions
def get_conserved_regions(msa: MultipleSeqAlignment):

    # Empty dictinary for the new sequence
    aligned_sequences = {}
    
    conserved_msa = MultipleSeqAlignment([])
    
    seq_length = len(msa)  # number of sequences
    align_len = msa.get_alignment_length()  # length of each sequence
    
    for i in range(0, align_len - 1):
        non_gap = 0
        for j in range(0, seq_length - 1):  # iterate through each sequence in the alignment
            if msa[j].seq[i] != '-':  # count non-gap characters
                non_gap += 1

        # compute percent of gaps in the sequence
        percent_non_gap = (non_gap * 100) / seq_length  

        # discard sequences with gaps more than 5%. 
        if (percent_non_gap >= 95):  
            num_pairs = 0
            num_identical = 0

            # iterate through each sequence in the alignment
            for j in range(0, seq_length - 1):  
                seq_j = msa[j].seq[i]
                for k in range(j + 1, seq_length - 1):
                    seq_k = msa[k].seq[i]
                    num_pairs = num_pairs + 1
                    if seq_j != '-' and seq_k != '-':  # count matching characters
                        if seq_k == seq_j:
                            num_identical = num_identical + 1
            
            # compute percent of matches against a column in all the sequences in the alignment
            percent_identical = (num_identical * 100) / num_pairs  
            
            # discard columns that are not at least 75% identical
            if (percent_identical >= 75):  
                for j in range(0, seq_length - 1):  # add cleaned gene strings to an array
                    seq_j = msa[j].seq[i]
                    str_val = msa[j].id
                    if str_val not in aligned_sequences:
                        aligned_sequences[str_val] = seq_j
                    else:
                        aligned_sequences.update({str_val: (aligned_sequences[msa[j].id] + seq_j)})

    # build sequences from the cleaned strings to form new Multiple Alignment Sequence
    for key in aligned_sequences:  
        seq = Seq(aligned_sequences[key])
        processed_seq = SeqRecord.SeqRecord(seq, id=key)
        conserved_msa.append(processed_seq)

    return conserved_msa

def upgma_pylogeneticTree_construction(aln, gene_positions):

    dendropyTrees = []

    for gene in gene_positions:   

        # Clean and extract sequences for each gene by position coordinates    
        gene_msa = extract_gene_by_position(aln, int(gene[1]),int(gene[2]))
        # get conserved regions from the gene sequence
        conserved_msa = get_conserved_regions(gene_msa)

        # skip conserved region if the substutions are high
        if len(conserved_msa) == 0 :
            conserved_msa = gene_msa 

        # Calculate distance matrix
        distance_calculator = DistanceCalculator('identity')
        distance_matrix = distance_calculator.get_distance(conserved_msa)

        # Build tree with UPGMA algorithm
        upgma_tree_obj = DistanceTreeConstructor().upgma(distance_matrix)
        # Setup Plot configuration
        plot_figure = plt.figure(figsize=(15, 25), dpi=100)
        axes = plot_figure.add_subplot(1, 1, 1) 

        # Convert the distance matrix to a NumPy array
        distance_array = np.array(distance_matrix)

        # Find the maximum value in the array
        xmax = distance_array.max()
        axes.set_xlim(-0.05 * xmax, 1.25 * xmax + 0.1) 

        # Draw Phylogenetic tree and save as image
        Phylo.draw(upgma_tree_obj, axes=axes, do_show=False)
        plt.savefig("output/upgma/upgmaTree_"+gene[0]+".png")

        # write tree to output folder in Newick format
        Phylo.write(upgma_tree_obj, "output/upgma/upgmaTree_"+gene[0]+"_Newick.nwk", "newick")
        
        # proccess newick files and create DendroPy trees
        dendropyTree_obj = dendropy.Tree.get(
                path="output/upgma/upgmaTree_"+gene[0]+"_Newick.nwk",
                schema="newick",
                taxon_namespace=tns_namespace,
                suppress_internal_node_taxa=False,
                preserve_underscores=True)

        dendropyTree_obj.encode_bipartitions()
        # store DendroPy trees in an array with its gene name
        dendropyTrees.append([gene[0], dendropyTree_obj])

    return dendropyTrees


def nj_pylogeneticTree_construction(aln, gene_positions):

    dendropyTrees = []

    for gene in gene_positions:   

        # Clean and extract sequences for each gene by position coordinates    
        gene_msa = extract_gene_by_position(aln, int(gene[1]),int(gene[2]))
        # get conserved regions from the gene sequence
        conserved_msa = get_conserved_regions(gene_msa)

        # skip conserved region if the substutions are high
        if len(conserved_msa) == 0 :
            conserved_msa = gene_msa 

        # Calculate distance matrix
        distance_calculator = DistanceCalculator('identity')
        distance_matrix = distance_calculator.get_distance(conserved_msa)

        # Build tree with neighbour joining algorithm
        njTree_obj = DistanceTreeConstructor().nj(distance_matrix)

        # Setup Plot configuration
        plot_figure = plt.figure(figsize=(15, 25), dpi=100)
        axes = plot_figure.add_subplot(1, 1, 1)  
        
        # Convert the distance matrix to a NumPy array
        distance_array = np.array(distance_matrix)

        # Find the maximum value in the array
        xmax = distance_array.max()
        axes.set_xlim(-0.05 * xmax, 1.25 * xmax + 0.1)

        # Draw Phylogenetic tree and save as image
        Phylo.draw(njTree_obj, axes=axes, do_show=False)
        plt.savefig("output/nj/njTree_"+gene[0]+".png")

        # write tree to output folder in Newick format
        Phylo.write(njTree_obj, "output/nj/njTree_"+gene[0]+"_Newick.nwk", "newick")
        
        # proccess newick files and create dendropy tree
        dendropyTree_obj = dendropy.Tree.get(
                path="output/nj/njTree_"+gene[0]+"_Newick.nwk",
                schema="newick",
                taxon_namespace=tns_namespace,
                suppress_internal_node_taxa=False,
                preserve_underscores=True)

        dendropyTree_obj.encode_bipartitions()
        # store DendroPy trees in an array with its gene name
        dendropyTrees.append([gene[0], dendropyTree_obj])

    return dendropyTrees


# read input file
align = list(AlignIO.parse("input/multi.sars-like.maf","maf"))

# extract list of genomes from the input alignment file
genomeList = get_genome_list (align)

# extract gene positions from SARS CoV structure
gene_positions = get_gene_positions()


#pylogenetic tree construction
upgma_dendropyTrees = upgma_pylogeneticTree_construction(align, gene_positions)
nj_dendropyTrees = nj_pylogeneticTree_construction(align, gene_positions)


#initiaze the empty lists for the robinson foulds distnace for both algorithms
rf_upgma_data =[]
rf_nj_data =[]

#iterate through upgma dendropy trees
for i in range(0, len(upgma_dendropyTrees)): 
    for j in range(i+1, len(upgma_dendropyTrees)):
        # Compute Robinson Foulds distance between trees
        RF_distance = treecompare.robinson_foulds_distance(upgma_dendropyTrees[i][1], upgma_dendropyTrees[j][1])
        rf_upgma_data.append([upgma_dendropyTrees[i][0], upgma_dendropyTrees[j][0], round(RF_distance,4)])

#iterate through nj dendropy trees
for i in range(0, len(nj_dendropyTrees)): 
    for j in range(i+1, len(nj_dendropyTrees)):
        # Compute Robinson Foulds distance between trees
        RF_distance = treecompare.robinson_foulds_distance(nj_dendropyTrees[i][1], nj_dendropyTrees[j][1])	
        rf_nj_data.append([nj_dendropyTrees[i][0], nj_dendropyTrees[j][0], round(RF_distance, 4)])

#Function to convert the data into data frame
def convert_to_dataframe(upgma_data, nj_data):

    # Create a DataFrame from a dictionary
    genomeName_list =[]
    upgma_list = []
    nj_list =[]

    for i in upgma_data:
        genomeName_list.append(i[0] +"-"+i[1])
        upgma_list.append(i[2])

    for j in nj_data:
        for i in genomeName_list:
            if i == (j[0] +"-"+j[1]):
                nj_list.append(j[2])

    data = {'Genomes': genomeName_list,
            'UPGMA': upgma_list,
            'NJ': nj_list}

    df = pd.DataFrame(data)

    return df

	
#Function to generate the bar graph with data
def draw_barGraph(df,name):
    # Set the 'Genomes' column as the index
    df.set_index('Genomes', inplace=True)
    # Plotting the data
    df.plot(kind='bar')
    plt.xlabel('Genomes')
    plt.ylabel(name)
    plt.title('UPGMA and NJ '+name+' Comparison')
    plt.legend(['UPGMA', 'NJ'],loc='upper left', bbox_to_anchor=(1, 1))
    plt.xticks(rotation=90)
    plt.show()


# Function to generate the HeatMap with data
def heatmap_generator(data, name):

    columns = ['Tree1', 'Tree2', 'Distance']

    # Create a DataFrame from the collected data
    df_data = pd.DataFrame(data, columns=columns)

    # Create a pivot table for heatmap
    heatmap_data = df_data.pivot(index='Tree1', columns='Tree2', values='Distance')

    # Create a heatmap using seaborn
    plt.figure(figsize=(10, 8))
    sns.heatmap(heatmap_data, annot=True, cmap='Blues', fmt=".4f", cbar_kws={'label': 'Distance'})
    plt.title(name)
    plt.show()


# calling the function to get the robinson foulds distnace
rf_data = convert_to_dataframe(rf_upgma_data, rf_nj_data)

# Print the output data
print("Robinson Foulds distance Data Frame")
print(rf_data)

# function call for the bar chart and heat map 
draw_barGraph(rf_data, "Robinson Foulds distance")
heatmap_generator(rf_upgma_data, "UPGMA Robinson Foulds distance")
heatmap_generator(rf_nj_data, "Neighbour Joining Robinson Foulds distance")







